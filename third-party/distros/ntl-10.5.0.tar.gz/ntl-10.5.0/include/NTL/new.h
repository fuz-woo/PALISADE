
#ifndef NTL_new__H
#define NTL_new__H

#include <NTL/config.h>
#include <new>

#define NTL_NEW_OP new (std::nothrow)


#endif
