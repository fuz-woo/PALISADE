#include <NTL/config.h>


double _ntl_GetTime()
{
   return 0;
}
